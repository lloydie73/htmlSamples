/* © Big Red Communications Group Pty Ltd 2017. All Rights Reserved.
You may not copy, reproduce or communicate any of the contents of this file without the permission of the copyright owner.*/

if(document.addEventListener) {
	console.log("window.addEventListener");
 	window.addEventListener( "load", allDocIsReady, false )
} else {
	console.log("NO window.addEventListener");
 	window.attachEvent('onload', allDocIsReady);
}
function swapCta(evt){ 
  new TweenLite.to('#btn_cta', 0.25, {css:{backgroundColor:"#E01A22"}, ease:Linear.easeInOut});
  document.getElementById('btn_cta_label').src="./btn_cta_label_wht.svg";
  document.getElementById('btn_cta_arrow').src="./btn_cta_arrow_wht.svg";
}

function swapCtaBack(evt){
  	new TweenLite.to('#btn_cta', 0.25, {css:{backgroundColor:"#FFFFFF"}, ease:Linear.easeInOut});
  	document.getElementById('btn_cta_label').src="./btn_cta_label.svg";
  	document.getElementById('btn_cta_arrow').src="./btn_cta_arrow.svg";

}


function allDocIsReady() {

	//listeners
	document.getElementById('btn_cta').addEventListener('mouseover', swapCta, false);
	document.getElementById('btn_cta').addEventListener('mouseout', swapCtaBack, false);

	var theTimeline = new TimelineLite();
	var loopCount = 1;
	
	TweenLite.set('#the_blind', {opacity:0});

	//Frame 1
	theTimeline.add(new TweenLite.from('#roundel', 0.15, {opacity:0, scaleX:0.2, ease:Sine.easeInOut}));
	theTimeline.add(new TweenLite.to('#roundel', 0.1, {scaleX:0.3, opacity:0.7, ease:Sine.easeInOut}));
	theTimeline.add(new TweenLite.to('#roundel', 0.2, {scaleX:1.1, opacity:1, ease:Sine.easeInOut}));
	theTimeline.add(new TweenLite.to('#roundel', 0.20, {scaleX:0.3, ease:Sine.easeInOut}));
	theTimeline.add(new TweenLite.to('#roundel', 0.50, {scaleX:1, ease:Sine.easeInOut}));

	theTimeline.add(new TweenLite.from('#copy1', 0.5, {y:-10, ease:Back.easeOut, opacity:0}));
	theTimeline.add(new TweenLite.from('#copy2', 0.5, {y:-10, ease:Back.easeOut, opacity:0, delay:-0.25}));

	theTimeline.add(new TweenLite.fromTo('#roundel_shine', 2, {opacity:0, x:-180}, {opacity:1, x:250, ease:Strong.easeOut}));

	theTimeline.add(new TweenLite.to('#roundel', 0.15, {scaleX: 0.3, ease:Sine.easeInOut}));
	theTimeline.add(new TweenLite.to('#roundel', 0.1, {scaleX: 1.1, ease:Sine.easeInOut}));
	theTimeline.add(new TweenLite.to('#roundel', 0.20, {scaleX: 0.2, opacity:0, ease:Sine.easeInOut}));
	theTimeline.add(new TweenLite.to('#copy1', 0.2, {opacity:0, delay:-0.2}));
	theTimeline.add(new TweenLite.to('#copy2', 0.2, {opacity:0, delay:-0.2}));

	//Frame 2
	theTimeline.add(new TweenLite.from('#red_foreground', 0.5, {opacity:0}));
	theTimeline.add(new TweenLite.from('#copy3', 0.5, {y:-10, ease:Back.easeOut, opacity:0}));
	theTimeline.add(new TweenLite.from('#copy4', 0.5, {y:-10, ease:Back.easeOut, opacity:0, delay:-0.25}));
	theTimeline.add(new TweenLite.from('#shopping_wrapper', 0.7, {x:-260, ease:Sine.easeOut}));
	theTimeline.add(new TweenMax.from('#delivery_bag_apple', 0.2, {y:10, ease:Sine.easeInOut, delay:0.25}));
	theTimeline.add(new TweenMax.from('#delivery_bag_broccoli', 0.2, {y:10, ease:Sine.easeInOut, delay:-0.10}));
	theTimeline.add(new TweenMax.from('#delivery_bag_carrot', 0.2, {y:10, ease:Sine.easeInOut, delay:-0.35}));
	theTimeline.add(new TweenMax.from('#delivery_bag_bread', 0.2, {y:10, ease:Sine.easeInOut, delay:-0.30}));
	theTimeline.add(new TweenMax.from('#delivery_bag_bottle2', 0.2, {y:10, ease:Sine.easeInOut, delay:-0.45}));
	theTimeline.add(new TweenMax.from('#delivery_bag_orange', 0.2, {y:10, ease:Sine.easeInOut, delay:-0.55}));	
	theTimeline.add(new TweenMax.from('#delivery_bag_bag', 0.2, {y:10, ease:Sine.easeInOut, delay:-0.50}));
	theTimeline.add(new TweenMax.from('#delivery_bag_bottle1', 0.2, {y:10, ease:Sine.easeInOut, delay:-0.40}));

	//Frame 3
	theTimeline.add(new TweenLite.to('#copy3', 0.2, {opacity:0}));
	theTimeline.add(new TweenLite.to('#copy4', 0.2, {opacity:0, delay:-0.2}));

	theTimeline.add(new TweenLite.fromTo('#hand_open', 1, {x:120, y:-20, rotation:0}, {x:-59, y:10, rotation:-20, ease:Sine.easeInOut}));
	theTimeline.add(new TweenLite.fromTo('#hand_closed', 1, {x:120, y:-20, rotation:0}, {x:-59, y:10, rotation:-20, delay:-1, ease:Sine.easeInOut, onComplete:swapHands}));

	theTimeline.add(new TweenLite.to('#hand_closed', 0.7, {x:115, y:-20, rotation:0, delay:0.5, ease:Sine.easeInOut}));
	theTimeline.add(new TweenLite.to('#shopping_wrapper', 0.7, {x:160, y:-40, rotation:30, delay:-0.7, ease:Sine.easeInOut}));
	theTimeline.add(new TweenLite.to('#shopping_wrapper', 0.25, {x:300, ease:Sine.easeInOut}));

	theTimeline.add(new TweenLite.from('#copy5', 0.5, {y:-10, ease:Back.easeOut, opacity:0, delay:-2}));
	theTimeline.add(new TweenLite.from('#copy6', 0.5, {y:-10, ease:Back.easeOut, opacity:0, delay:-1.75}));

	theTimeline.add(new TweenLite.to('#copy5', 0.2, {opacity:0, delay:0.2}));
	theTimeline.add(new TweenLite.to('#copy6', 0.2, {opacity:0, delay:-0.2}));

	//Frame 4
	theTimeline.add(new TweenLite.from('#roundel_sml', 0.15, {opacity:0, scaleX:0.2, ease:Sine.easeInOut}));
	theTimeline.add(new TweenLite.to('#roundel_sml', 0.1, {scaleX:0.3, opacity:0.7, ease:Sine.easeInOut}));
	theTimeline.add(new TweenLite.to('#roundel_sml', 0.2, {scaleX:1.1, opacity:1, ease:Sine.easeInOut}));
	theTimeline.add(new TweenLite.to('#roundel_sml', 0.20, {scaleX:0.3, ease:Sine.easeInOut}));
	theTimeline.add(new TweenLite.to('#roundel_sml', 0.50, {scaleX:1, ease:Sine.easeInOut}));

	theTimeline.add(new TweenLite.from('#copy7', 0.5, {y:-10, ease:Back.easeOut, opacity:0}));
	theTimeline.add(new TweenLite.from('#copy8', 0.5, {y:-10, ease:Back.easeOut, opacity:0, delay:-0.2}));
	theTimeline.add(new TweenLite.from('#copy9', 0.5, {y:-10, ease:Back.easeOut, opacity:0, delay:-0.5}));
	theTimeline.add(new TweenLite.fromTo('#copy2', 0.5, {y:-10, opacity:0}, {y:0, opacity:1, delay:-0.2, ease:Back.easeOut}));

	theTimeline.add(new TweenLite.fromTo('#roundel_shine_sml', 2.50, {opacity:0, x:-100}, {opacity:1, x:250, ease:Strong.easeOut, onComplete:checkLoop}));

	
	function swapHands(){
		TweenLite.set('#hand_open', {opacity:0});
		TweenLite.set('#hand_closed', {opacity:1});
	}

	console.log('Duration is ' + theTimeline.duration());


	function pause() {
		theTimeline.stop();
	}

	function checkLoop() {
		if (loopCount > 1 ) {
			theTimeline.stop();
		
		} else {
			loopCount++;
		}
	}


	function restartTimeline() {
		theTimeline.restart();
		deliveryTimeline.restart();
	}	
}