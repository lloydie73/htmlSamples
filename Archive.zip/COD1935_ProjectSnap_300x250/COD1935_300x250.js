/*© Big Red Communications Group Pty Ltd 2017. All Rights Reserved.
You may not copy, reproduce or communicate any of the contents of this file without the permission of the copyright owner.*/

if(document.addEventListener) {
 	window.addEventListener( "load", allDocIsReady, false )
} else {
 	window.attachEvent('onload', allDocIsReady);
}
function swapCta(evt){ 
  new TweenLite.to('#btn_cta', 0.25, {css:{backgroundColor:"#E01A22"}, ease:Linear.easeInOut});
  document.getElementById('btn_cta_label').src="./btn_cta_label_wht.svg";
  document.getElementById('btn_cta_arrow').src="./btn_cta_arrow_wht.svg";
}

function swapCtaBack(evt){
  	new TweenLite.to('#btn_cta', 0.25, {css:{backgroundColor:"#FFFFFF"}, ease:Linear.easeInOut});
  	document.getElementById('btn_cta_label').src="./btn_cta_label.svg";
  	document.getElementById('btn_cta_arrow').src="./btn_cta_arrow.svg";

}


function allDocIsReady() {

	//listeners
	document.getElementById('btn_cta').addEventListener('mouseover', swapCta, false);
	document.getElementById('btn_cta').addEventListener('mouseout', swapCtaBack, false);

	var theTimeline = new TimelineMax();
	var lockupTimeline = new TimelineMax();
	var lockupTimelineCopy = new TimelineMax();
	var loopCount = 1;
	
	TweenLite.set('#the_blind', {opacity:0});

	//Frame 1
	lockupTimeline.add(new TweenMax.fromTo('#shapeContainerRightTop', 0.2, {scaleX:0}, {scaleX:1, ease:Power1.easeInOut}));
	lockupTimeline.add(new TweenMax.fromTo('#shapeContainerRight', 0.2, {scaleY:0}, {scaleY:1, ease:Power1.easeInOut}));
	lockupTimeline.add(new TweenMax.fromTo('#shapeContainerBottom', 0.2, {scaleX:0}, {scaleX:1, ease:Power1.easeInOut}));
	lockupTimeline.add(new TweenMax.fromTo('#shapeContainerLeft', 0.2, {scaleY:0}, {scaleY:1, ease:Power1.easeInOut}));
	lockupTimeline.add(new TweenMax.fromTo('#shapeContainerLeftTop', 0.2, {scaleX:0}, {scaleX:1, ease:Power1.easeInOut}));

	lockupTimelineCopy.add(new TweenMax.fromTo('#lockupCopy1', 0.5, {scale:0, x:50}, {scale:1.4, x:50, ease:Back.easeOut}));
	lockupTimelineCopy.add(new TweenMax.to('#lockupCopy1', 0.5, {scale:1, x:0, ease:Back.easeOut}));
	lockupTimelineCopy.add(new TweenMax.fromTo('#lockupCopy2', 0.5, {scale:0}, {scale:1, ease:Back.easeOut, delay:-0.5}));

	lockupTimelineCopy.add(new TweenMax.from('#copy1', 0.5, {y:-5, opacity:0, ease:Strong.easeOut}));
	lockupTimelineCopy.add(new TweenMax.from('#copy2', 0.5, {y:-5, opacity:0, ease:Strong.easeOut}));

	//Frame 2
	theTimeline.add(new TweenMax.to('.frameOne', 0.5, {opacity:0, delay:2.5}));
	theTimeline.add(new TweenMax.to('#productsLeft', 0.5, {x:-90, delay:-0.5, ease:Back.easeIn.config(0.2)}));
	theTimeline.add(new TweenMax.to('#productsRight', 0.5, {x:90, delay:-0.5, ease:Back.easeIn.config(0.2)}));

	theTimeline.add(new TweenMax.from('#imgProducts', 0.5, {x:-200, ease:Back.easeOut}));
	theTimeline.add(new TweenMax.to('#imgProducts', 0.5, {x:220, ease:Back.easeIn, delay:1.5}));

	//Frame 3
	theTimeline.add(new TweenMax.to('#productsLeft', 0.5, {x:0, ease:Back.easeOut.config(0.2)}));
	theTimeline.add(new TweenMax.to('#productsRight', 0.5, {x:0, delay:-0.5, ease:Back.easeOut.config(0.2),}));

	theTimeline.add(new TweenMax.fromTo('#step1', 0.5, {scale:0}, {scale:1.1, ease:Back.easeOut}));
	theTimeline.add(new TweenMax.to('#step1', 0.25, {scale:1, ease:Back.easeIn, delay:-0.25}));
	theTimeline.add(new TweenMax.fromTo('#step2', 0.5, {scale:0}, {scale:1.1, ease:Back.easeOut}));
	theTimeline.add(new TweenMax.to('#step2', 0.25, {scale:1, ease:Back.easeIn, delay:-0.25}));
	theTimeline.add(new TweenMax.fromTo('#step3', 0.5, {scale:0}, {scale:1.1, ease:Back.easeOut}));
	theTimeline.add(new TweenMax.to('#step3', 0.25, {scale:1, ease:Back.easeIn, delay:-0.25}));
	theTimeline.add(new TweenMax.fromTo('#step4', 0.5, {scale:0}, {scale:1.1, ease:Back.easeOut}));
	theTimeline.add(new TweenMax.to('#step4', 0.25, {scale:1, ease:Back.easeIn, delay:-0.25}));

	theTimeline.add(new TweenMax.to('#step1', 0.2, {opacity:0, delay:2}));
	theTimeline.add(new TweenMax.to('#step2', 0.2, {opacity:0, delay:-0.2}));
	theTimeline.add(new TweenMax.to('#step3', 0.2, {opacity:0, delay:-0.2}));
	theTimeline.add(new TweenMax.to('#step4', 0.2, {opacity:0, delay:-0.2, onComplete:replayFirstFrame}));

	theTimeline.add(new TweenMax.fromTo('#disclaimer', 0.5, {y:50}, {y:0, delay:2, ease:Strong.easeOut, onComplete:checkLoop}));

	function replayFirstFrame() {
		TweenMax.set('.frameOne', {opacity:1});
		lockupTimeline.restart();
		lockupTimelineCopy.restart();
	}

	function pause() {
		theTimeline.stop();
	}


	function checkLoop() {
		if (loopCount > 1 ) {
			theTimeline.stop();
			lockupTimeline.stop();
			lockupTimelineCopy.stop();
			console.log('test');
		
		} else {
			loopCount++;
		}
	}

	function restartTimeline() {
		theTimeline.restart();
		lockupTimeline.restart();
		lockupTimelineCopy.restart();
		//zoomTimeline.restart();
	}	
}