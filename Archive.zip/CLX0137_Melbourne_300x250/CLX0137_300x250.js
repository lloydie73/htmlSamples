/* © Big Red Communications Group Pty Ltd 2017. All Rights Reserved.
You may not copy, reproduce or communicate any of the contents of this file without the permission of the copyright owner.*/

if(document.addEventListener) {
 	window.addEventListener( "load", allDocIsReady, false )
} else {
 	window.attachEvent('onload', allDocIsReady);
}
// function swapCta(evt){ 
//   new TweenLite.to('#btn_cta', 0.25, {css:{backgroundColor:"#E01A22"}, ease:Linear.easeInOut});
//   document.getElementById('btn_cta_label').src="./btn_cta_label_wht.png";
//   document.getElementById('btn_cta_arrow').src="./btn_cta_arrow_wht.png";
// }

// function swapCtaBack(evt){
//   	new TweenLite.to('#btn_cta', 0.25, {css:{backgroundColor:"#FFFFFF"}, ease:Linear.easeInOut});
//   	document.getElementById('btn_cta_label').src="./btn_cta_label.png";
//   	document.getElementById('btn_cta_arrow').src="./btn_cta_arrow.png";

// }


function allDocIsReady() {

	//listeners
	// document.getElementById('btn_cta').addEventListener('mouseover', swapCta, false);
	// document.getElementById('btn_cta').addEventListener('mouseout', swapCtaBack, false);
	document.getElementById('the_blind').addEventListener('click', goClickthrough, false);

	var theTimeline = new TimelineLite();
	var loopCount = 1;
	
	TweenLite.set('#the_blind', {opacity:0});

	//Frame 1
	theTimeline.add(new TweenLite.from('#copy1', 0.50, {opacity:0, y:10}));
	theTimeline.add(new TweenLite.to('#copy1', 0.50, {opacity:0, delay:1.5}));
	//Frame 2
	theTimeline.add(new TweenLite.from('#tramTracks', 0.25, {opacity:0}));
	theTimeline.add(new TweenLite.fromTo('#tram', 3.25, {scale:0.22, x:200}, {scale:5.2, x:-1100, delay:-1, ease:Strong.easeIn}));
	theTimeline.add(new TweenLite.fromTo('#tram', 3.25, {y:15}, {y:-75, delay:-3.25, ease:Strong.easeIn}));
	theTimeline.add(new TweenLite.to('#tramTracks', 0.25, {opacity:0}));
	//Frame 3
	theTimeline.add(new TweenLite.from('#copy2', 0.50, {opacity:0, y:10}));
	theTimeline.add(new TweenLite.to('#copy2', 0.50, {opacity:0, delay:1.5}));
	//Frame 4
	theTimeline.add(new TweenLite.to('#coffee', 0.50, {x:124, ease:Strong.easeInOut}));
	theTimeline.add(new TweenLite.from('#flag', 0.50, {rotation:30, ease:Ease.easeOut, onComplete:checkLoop}));

	theTimeline.add(new TweenLite.to('#flag', 0.50, {rotation:30, ease:Ease.easeOut, delay:3}));
	theTimeline.add(new TweenLite.to('#coffee', 0.50, {x:0, ease:Strong.easeInOut, onComplete:restartTimeline}));
	


	var pattern = new Image();
	pattern.src = "flag.png";
	var ph = pattern.height;
	var theInterval;
	    
	function animate()
	{
	   theInterval = setInterval(drawShape, 200);
	}
	         
	function drawShape()
	{
	   var canvas = document.getElementById('flag');
	   var ctx = canvas.getContext('2d');
	   var iw = pattern.width;
	   var ih = pattern.height;
	   ctx.clearRect(0, 0, 204, 204);

	   if(ph <= 0)
	   {
	      ph = ih;
	   }
	   else
	   {
	      ph -= 10;
	   }

	   for(var x = 0; x < iw; x++)
	   {
	      // 8 = height of wave, 20 = frequency, 38 = vertical offset
	      var y = 3 * Math.sin((x + ph)/30) + 15;
	      ctx.drawImage(pattern, x, 0, 1, ih, x, y, 1, ih);
	   }
	}

	animate();


	function checkLoop() {
		if (loopCount > 0 ) {

			finishTimeline();
		} else {
			loopCount++;
			restartTimeline();
		}
	}

	function restartTimeline() {
		theTimeline.restart();
	}	
	function finishTimeline() {
		theTimeline.add(new TweenLite.fromTo('#tram', 3, {scale:0.22, x:200, y:15}, {scale:1, x:0, y:0, delay:1, ease:Ease.easeInOut, onComplete:finishFlag}));
	}	
	function finishFlag() {
		clearInterval(theInterval);
	}

	function goClickthrough(){
		Enabler.exit('main exit');
	}
}