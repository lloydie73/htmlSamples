/* © Big Red Communications Group Pty Ltd 2017. All Rights Reserved.
You may not copy, reproduce or communicate any of the contents of this file without the permission of the copyright owner.*/

if(document.addEventListener) {
	console.log("window.addEventListener");
 	window.addEventListener( "load", allDocIsReady, false )
} else {
	console.log("NO window.addEventListener");
 	window.attachEvent('onload', allDocIsReady);
}
function swapCta(evt){ 
  new TweenLite.to('#btn_cta', 0.25, {css:{backgroundColor:"#E01A22"}, ease:Linear.easeInOut});
  document.getElementById('btn_cta_label').src="./btn_cta_label_wht.svg";
  document.getElementById('btn_cta_arrow').src="./btn_cta_arrow_wht.svg";
}

function swapCtaBack(evt){
  	new TweenLite.to('#btn_cta', 0.25, {css:{backgroundColor:"#FFFFFF"}, ease:Linear.easeInOut});
  	document.getElementById('btn_cta_label').src="./btn_cta_label.svg";
  	document.getElementById('btn_cta_arrow').src="./btn_cta_arrow.svg";

}


function allDocIsReady() {

	//listeners
	document.getElementById('btn_cta').addEventListener('mouseover', swapCta, false);
	document.getElementById('btn_cta').addEventListener('mouseout', swapCtaBack, false);

	var theTimeline = new TimelineLite();
	var sparkleTimeline = new TimelineMax({repeat:2});

	var loopCount = 0;

	//randomise sparkles
	function goSparkles(){
		if (loopCount > 0){
			sparkleTimeline.restart();
		} else {
			var theSparkles = [null, '#sparkle1', '#sparkle2', '#sparkle3', '#sparkle4', '#sparkle5', '#sparkle6']
			for (i=1; i<7; i++){
				var whichOne = Math.ceil(Math.random()*6); 
				sparkleTimeline.add(new TweenLite.fromTo(theSparkles[i], 0.35, {scale:0.1, opacity:0},{scale:1, opacity:1, delay:whichOne/4}));
				sparkleTimeline.add(new TweenLite.to(theSparkles[i], 0.15, {scale:0.1, opacity:0}));
				sparkleTimeline.add(new TweenLite.to(theSparkles[i], 0.5, {rotation:180, delay:-0.5}));
			}
		}
	}
	
	TweenLite.set('#the_blind', {opacity:0});

	//pause();

	//Frame 1	
	theTimeline.add(new TweenLite.fromTo('#gerry', 0.5, {y:300, x:0}, {y:70,x:0, ease:Power2.easeOut, onStart:setScale1})); //
	theTimeline.add(new TweenLite.to('#gerryFore', 0.25, {y:-15, ease:Ease.easeInOut}));
	theTimeline.add(new TweenLite.to('#gerryFore', 0.25, {y:0, delay:0.25, ease:Ease.easeInOut}));
	theTimeline.add(new TweenLite.fromTo('#shine', 0.75, {x:-164, y:-164}, {x:328, y:328, delay:-0.25, ease:Ease.easeInOut}));
	theTimeline.add(new TweenLite.from('#disclaim1', 0.2, {opacity:0, y:10}));

	theTimeline.add(new TweenLite.fromTo('#sparkle7', 0.35, {scale:0.1, opacity:0},{scale:1, opacity:1, delay:1}));
	theTimeline.add(new TweenLite.to('#sparkle7', 0.15, {scale:0.1, opacity:0}));
	theTimeline.add(new TweenLite.to('#sparkle7', 0.5, {rotation:180, delay:-0.5}));
	theTimeline.add(new TweenLite.fromTo('#sparkle8', 0.35, {scale:0.1, opacity:0},{scale:1, opacity:1, delay:1}));
	theTimeline.add(new TweenLite.to('#sparkle8', 0.15, {scale:0.1, opacity:0}));
	theTimeline.add(new TweenLite.to('#sparkle8', 0.5, {rotation:180, delay:-0.5}));
	theTimeline.add(new TweenLite.fromTo('#sparkle9', 0.35, {scale:0.1, opacity:0},{scale:1, opacity:1, delay:1}));
	theTimeline.add(new TweenLite.to('#sparkle9', 0.15, {scale:0.1, opacity:0}));
	theTimeline.add(new TweenLite.to('#sparkle9', 0.5, {rotation:180, delay:-0.5}));

	theTimeline.add(new TweenLite.to('#gerry', 0.5, {y:350, rotation:0, ease:Power4.easeIn}));
	//theTimeline.add(new TweenLite.to('#gerryShadow', 0.4, {x:300, delay:-0.4, ease:Back.easeIn}));
	theTimeline.add(new TweenLite.to('#disclaim1', 0.2, {opacity:0, delay:-0.2}));

	//Frame 2
	theTimeline.add(new TweenLite.fromTo('#headerRibbon1', 0.25, {scaleX:0.10, opacity:0}, {scaleX:1, opacity:1, ease:Strong.easeOut, onStart:setScale2}));
	theTimeline.add(new TweenLite.fromTo('#headerRibbon2', 0.25, {scaleX:0.10, opacity:0}, {scaleX:1, opacity:1, delay:-0.25, ease:Strong.easeOut}));

	theTimeline.add(new TweenLite.from('#copy3', 0.5, {x:-20, opacity:0, ease:Back.easeOut}));
	theTimeline.add(new TweenLite.fromTo('#copy4', 0.5, {x:-20, opacity:0},{x:0, opacity:1, delay:-0.2, ease:Back.easeOut}));
	theTimeline.add(new TweenLite.from('#disclaim2', 0.5, {x:-20, opacity:0, ease:Back.easeOut}));


	theTimeline.add(new TweenLite.fromTo('#starGold4', 0.5, {scale:0.1, opacity:0},{scale:1, opacity:1, delay:-0.3, ease:Bounce.easeOut, onComplete:goSparkles}));
	theTimeline.add(new TweenLite.fromTo('#starGold2', 0.5, {scale:0.1, opacity:0},{scale:1, opacity:1, delay:-0.3, ease:Bounce.easeOut}));
	theTimeline.add(new TweenLite.fromTo('#starSilver1', 0.5, {scale:0.1, opacity:0},{scale:1, opacity:1, delay:-0.3, ease:Bounce.easeOut}));
	theTimeline.add(new TweenLite.fromTo('#starGold1', 0.5, {scale:0.1, opacity:0},{scale:1, opacity:1, delay:-0.3, ease:Bounce.easeOut}));
	theTimeline.add(new TweenLite.fromTo('#starSilver2', 0.5, {scale:0.1, opacity:0},{scale:1, opacity:1, delay:-0.3, ease:Bounce.easeOut}));
	theTimeline.add(new TweenLite.fromTo('#starGold3', 0.5, {scale:0.1, opacity:0},{scale:1, opacity:1, delay:-0.3, ease:Bounce.easeOut}));

	theTimeline.add(new TweenLite.fromTo('#gerry', 0.75, {y:143, x:300}, {y:143, x:183, ease:Back.easeOut, delay:1}));
	theTimeline.add(new TweenLite.fromTo('#gerryShadow', 0.75, {x:48}, {x:-68, ease:Back.easeOut, delay:-0.7, onComplete:checkLoop}));

	//out
	theTimeline.add(new TweenLite.to('#gerry', 0.25, {x:300, delay:2.5, ease:Back.easeIn}));
	theTimeline.add(new TweenLite.to('#gerryShadow', 0.25, {x:120, delay:-0.25, ease:Back.easeIn}));
	theTimeline.add(new TweenLite.to('#copy3', 0.25, {x:-10, opacity:0, delay:-0.25}));
	theTimeline.add(new TweenLite.to('#disclaim2', 0.25, {x:-10, opacity:0, delay:-0.25}));
	theTimeline.add(new TweenLite.to('#copy4', 0.25, {x:-10, opacity:0, delay:-0.25}));
	theTimeline.add(new TweenLite.to('#headerRibbon1', 0.25, {scaleX:0.10, opacity:0, delay:-0.25}));
	theTimeline.add(new TweenLite.to('#headerRibbon2', 0.25, {scaleX:0.10, opacity:0, delay:-0.25}));
	theTimeline.add(new TweenLite.to('#starGold4', 0.25, {scale:0.1, opacity:0, delay:-0.25, onStart:stopSparkles}));
	theTimeline.add(new TweenLite.to('#starGold2', 0.25, {scale:0.1, opacity:0, delay:-0.25}));
	theTimeline.add(new TweenLite.to('#starSilver1', 0.25, {scale:0.1, opacity:0, delay:-0.25}));
	theTimeline.add(new TweenLite.to('#starGold1', 0.25, {scale:0.1, opacity:0, delay:-0.25}));
	theTimeline.add(new TweenLite.to('#starSilver2', 0.25, {scale:0.1, opacity:0, delay:-0.25}));
	theTimeline.add(new TweenLite.to('#starGold3', 0.50, {scale:0.1, opacity:0, delay:-0.25, onComplete:restartTimeline}));//

	function setScale1(){
		TweenLite.set('#gerry', {scale:1});
	} 
	function setScale2(){
		TweenLite.set('#gerry', {scale:0.65});
	} 
	function stopSparkles(){
		sparkleTimeline.seek(0);
		sparkleTimeline.stop();
	}
	function checkLoop() {
		if (loopCount > 0 ) {
			theTimeline.stop();
			sparkleTimeline.seek(0);
			sparkleTimeline.stop();
			console.log('loop length IS '+theTimeline.duration()+ ' AND elapsed IS ' + theTimeline.time());
			console.log('total IS '+(theTimeline.duration() + theTimeline.time()).toFixed(2));		
		} else {
			loopCount++;
		}
	}

	function pause() {
		theTimeline.stop();
		sparkleTimeline.stop();
	}

	function restartTimeline() {
		theTimeline.restart();
	}	
}