
// Reference to the creative's various properties and elements.
var creative = {};


/**
 * Called on the window load event.
 */
function preInit() {
  setupDom();

  if (Enabler.isInitialized()) {
    init();
  } else {
    Enabler.addEventListener(
      studio.events.StudioEvent.INIT,
      init
    );
  }
}

/**
 * Set up references to DOM elements.
 */
function setupDom() {
  creative.dom = {};
  creative.dom.mainContainer = document.getElementById('main-container');
  creative.dom.exit = document.getElementById('exit');
  //creative.dom.image0 = document.getElementById('main-img-0');
}

/**
 * The Enabler is now initialized and any extra modules have been loaded.
 */
function init() {
  addListeners();
  // Polite loading
  if (Enabler.isVisible()) {
    show();
  }
  else {
    Enabler.addEventListener(studio.events.StudioEvent.VISIBLE, show);
  }
}

/**
 * Add appropriate listeners after the creative's DOM has been set up.
 */
function addListeners() {
  creative.dom.exit.addEventListener('click', exitClickHandler);
  document.getElementById('btn_cta').addEventListener("mouseover", swapCta);
  document.getElementById('btn_cta').addEventListener("mouseout", swapCtaBack);
}

/**
 *  Shows the ad.
 */
function show() {
  creative.dom.exit.style.display = "block";
  //creative.dom.image0.style.visibility  = 'visible';
  
  	//vars
	var loopCount = 0;
	
	//animate
	var theTimeline = new TimelineLite();
	
	//frame 1
	theTimeline.add( new TweenMax.to('#the_blind', 0.01, {opacity:0, scale:0.001, ease: Power1.easeInOut}));
	
	
	theTimeline.add( new TweenMax.from('#bg1', 0.5,{opacity:0, ease: Power1.easeInOut}));
	theTimeline.add( new TweenMax.from('#logo_coles', 0.25, {opacity:0, x:50, ease: Power1.easeInOut}));
	theTimeline.add( new TweenMax.from('#btn_cta', 0.25, {opacity:0, x:50, ease: Power1.easeInOut}));

	theTimeline.add( new TweenMax.from('#chat_bubble1', 0.5,{opacity:0, scale:0.25, ease: Back.easeOut}));
	theTimeline.add( new TweenMax.from('#copy1', 0.25,{opacity:0, y:10, ease: Back.easeOut}));
	theTimeline.add( new TweenMax.from('#copy2', 0.25,{opacity:0, y:5, ease: Back.easeOut}));
	
	//frame 2
	theTimeline.add( new TweenMax.to('#copy1', 0.25,{opacity:0, y:10, ease: Back.easeIn, delay:2}));
	theTimeline.add( new TweenMax.to('#copy2', 0.25,{opacity:0, y:5, ease: Back.easeIn, delay:-0.25}));
	theTimeline.add( new TweenMax.to('#chat_bubble1', 0.25,{opacity:0, scale:0.25, ease: Back.easeOut, delay:0.25}));
	theTimeline.add( new TweenMax.to('#logo_coles', 0.5, {opacity:0, ease: Power1.easeInOut}));
	theTimeline.add( new TweenMax.to('#bg2', 0.5,{opacity:1, ease: Power1.easeInOut, delay:-0.5}));
	theTimeline.add( new TweenMax.to('#logo_coles2', 0.5, {opacity:1, ease: Power1.easeInOut, delay:-0.5}));
	theTimeline.add( new TweenMax.from('#chat_bubble2', 0.5,{opacity:0, scale:0.25, ease: Back.easeOut}));
	theTimeline.add( new TweenMax.from('#copy3', 0.25,{opacity:0, y:10, ease: Back.easeOut}));
	theTimeline.add( new TweenMax.from('#copy4', 0.25,{opacity:0, y:5, ease: Back.easeOut}));
	
	theTimeline.add( new TweenMax.to('#copy3', 0.25,{opacity:0, y:10, ease: Back.easeIn, delay:2}));
	theTimeline.add( new TweenMax.to('#copy4', 0.25,{opacity:0, y:5, ease: Back.easeIn, delay:-0.25}));
	theTimeline.add( new TweenMax.to('#chat_bubble2', 0.25,{opacity:0, scale:0.25, ease: Back.easeOut, delay:0.25}));
	
	//frame 3
	theTimeline.add( new TweenMax.from('#chat_bubble3', 0.5,{opacity:0, scaleX:0.25, ease: Back.easeOut}));
	theTimeline.add( new TweenMax.from('#copy5', 0.25,{opacity:0, y:10, ease: Back.easeOut}));
	
	
	//frame 4
	theTimeline.add( new TweenMax.to('#copy5', 0.25,{opacity:0, y:10, ease: Back.easeIn, delay:2.5}));
	theTimeline.add( new TweenMax.to('#chat_bubble3', 0.25,{opacity:0, scaleX:0.9, ease: Power1.easeInOut}));
	theTimeline.add( new TweenMax.from('#chat_bubble4', 0.5,{opacity:0, scaleX:0.9, ease: Power1.easeOut}));
	theTimeline.add( new TweenLite.from('#roundel', 0.2,{scaleX:0.2, opacity:0, ease: Sine.easeInOut}));
	theTimeline.add( new TweenLite.to('#roundel', 0.2,{scaleX:0.3, opacity:0.7, ease: Sine.easeInOut}));
	theTimeline.add( new TweenLite.to('#roundel', 0.4,{scaleX:1, opacity:1, ease: Sine.easeInOut}));
	theTimeline.add( new TweenMax.from('#copy6', 0.25,{opacity:0, y:5, ease: Back.easeOut}));
}

// ---------------------------------------------------------------------------------
// MAIN
// ---------------------------------------------------------------------------------

function exitClickHandler() {
  Enabler.exit('BackgroundExit');
}
function swapCta (){
	document.getElementById('btn_cta').src = './cta_shopNowOver.png';
	//document.getElementById('btn_cta').style.opacity = 0.7;
}
function swapCtaBack (){
	document.getElementById('btn_cta').src = './cta_shopNow.png';
	//document.getElementById('btn_cta').style.opacity = 1;
}

/**
 *  Main onload handler
 */
window.addEventListener('load', preInit);