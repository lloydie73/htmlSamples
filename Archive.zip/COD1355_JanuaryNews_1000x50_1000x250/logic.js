
// Reference to the creative's various properties and elements.
var creative = {};
var theTimeline = new TimelineMax();
var buckingTimeline = new TimelineMax();
var buckingTimeline2 = new TimelineMax();
var buckingTimeline3 = new TimelineMax();

/**
 * Called on the window load event.
 */
function preInit() {
  setupDom();

  if (Enabler.isInitialized()) {
    init();
  } else {
    Enabler.addEventListener(
      studio.events.StudioEvent.INIT,
      init
    );
  }
}

/**
 * Set up references to DOM elements.
 */
function setupDom() {
  creative.dom = {};
  creative.dom.mainContainer = document.getElementById('main-container');
  creative.dom.expandedExit = document.getElementById('expanded-exit');
  creative.dom.expandedContent = document.getElementById('expanded-state');
  creative.dom.collapsedExit = document.getElementById('collapsed-exit');
  creative.dom.collapsedContent = document.getElementById('collapsed-state');
  creative.dom.collapseButton = document.getElementById('collapse-button');
  creative.dom.expandButton = document.getElementById('expand-button');
  creative.dom.image0 = document.getElementById('main-img-0');
  creative.dom.image1 = document.getElementById('main-img-1');
}

/**
 * The Enabler is now initialized and any extra modules have been loaded.
 */
function init() {
  Enabler.setStartExpanded(true);
  addListeners();
  // Polite loading
  if (Enabler.isVisible()) {
    show();
  }
  else {
    Enabler.addEventListener(studio.events.StudioEvent.VISIBLE, show);
  }
}

/**
 * Add appropriate listeners after the creative's DOM has been set up.
 */
function addListeners() {
  Enabler.addEventListener(studio.events.StudioEvent.EXPAND_START, expandStartHandler);
  Enabler.addEventListener(studio.events.StudioEvent.EXPAND_FINISH, expandFinishHandler);
  Enabler.addEventListener(studio.events.StudioEvent.COLLAPSE_START, collapseStartHandler);
  Enabler.addEventListener(studio.events.StudioEvent.COLLAPSE_FINISH, collapseFinishHandler);
  creative.dom.expandButton.addEventListener('click', onExpandHandler, false);
  creative.dom.collapseButton.addEventListener('click', onCollapseClickHandler, false);
  creative.dom.expandedExit.addEventListener('click', exitClickHandler);
  creative.dom.collapsedExit.addEventListener('click', collapsedExitClickHandler);

  document.getElementById('btn_cta').addEventListener('mouseover', swapCta, false);
  document.getElementById('btn_cta').addEventListener('mouseout', swapCtaBack, false);
  document.getElementById('btn_cta').addEventListener('click', exitClickHandler, false);

  document.getElementById('btn_cta_c').addEventListener('mouseover', swapCta, false);
  document.getElementById('btn_cta_c').addEventListener('mouseout', swapCtaBack, false);
  document.getElementById('btn_cta_c').addEventListener('click', exitClickHandler, false);

}
function swapCta(evt){ 
  document.getElementById(evt.target.id).src = "btn_cta_over.png";
}
function swapCtaBack(evt){
  document.getElementById(evt.target.id).src = "btn_cta.png";
}

/**
 *  Shows the ad.
 */
function show() {
  creative.dom.expandedContent.style.display = 'none';
  creative.dom.expandedExit.style.display = 'none';
  creative.dom.collapseButton.style.display = 'none';

  creative.dom.collapsedContent.style.display = 'block';
  creative.dom.collapsedExit.style.display = 'block';
  creative.dom.expandButton.style.display = 'block';
  creative.dom.image0.style.visibility  = 'visible';
  creative.dom.image1.style.visibility  = 'visible';
  onExpandHandler();
}

// ---------------------------------------------------------------------------------
// MAIN
// ---------------------------------------------------------------------------------


function expandStartHandler() {
  // Show expanded content.
  creative.dom.expandedContent.style.display = 'block';
  creative.dom.expandedExit.style.display = 'block';
  creative.dom.collapseButton.style.display = 'block';
  creative.dom.collapsedContent.style.display = 'none';
  creative.dom.collapsedExit.style.display = 'none';
  creative.dom.expandButton.style.display = 'none';

  Enabler.finishExpand();
}

function expandFinishHandler() {
  creative.isExpanded = true;

  animateExpanded();
}

function collapseStartHandler() {
  // Perform collapse animation.
  creative.dom.expandedContent.style.display = 'none';
  creative.dom.expandedExit.style.display = 'none';
  creative.dom.collapseButton.style.display = 'none';
  creative.dom.collapsedContent.style.display = 'block';
  creative.dom.collapsedExit.style.display = 'block';
  //creative.dom.expandButton.style.display = 'block';

  buckingTimeline.stop();
  buckingTimeline2.stop();
  buckingTimeline3.stop();

  // When animation finished must call
  Enabler.finishCollapse();

  animateCollapsed();
}

function collapseFinishHandler() {
  creative.isExpanded = false;
}

function onCollapseClickHandler(){
  Enabler.requestCollapse();
  Enabler.stopTimer('Panel Expansion');
}

function onExpandHandler(){
  Enabler.requestExpand();
  Enabler.startTimer('Panel Expansion');
}

function exitClickHandler() {
  Enabler.requestCollapse();
  theTimeline.stop();
  //theTimeline_c.stop();
  Enabler.stopTimer('Panel Expansion');
  Enabler.exit('BackgroundExit');
}

function collapsedExitClickHandler() {
  Enabler.exit('CollapsedExit');
}

function animateCollapsed(){
  //vars
  theTimeline_c = new TimelineMax();
  //frame 1
  //theTimeline.add( new TweenLite.to('#the_blind', 0.5, {opacity:0, ease: Strong.easeOut}));
  theTimeline_c.add( new TweenLite.from('#copy1_c', 0.25, {opacity:0, y:10, ease: Strong.easeOut}));
  theTimeline_c.add( new TweenLite.from('#roundel_c', 0.15, {opacity:0, scaleX:-0.01, ease: Sine.easeInOut}));
  theTimeline_c.add( new TweenLite.to('#roundel_c', 0.15, {scaleX:0.01, ease: Sine.easeInOut}));
  theTimeline_c.add( new TweenLite.to('#roundel_c', 0.15, {scaleX:0.5, ease: Sine.easeIn}));
  theTimeline_c.add( new TweenLite.to('#roundel_c', 0.20, {scaleX:1, ease: Back.easeOut}));
  theTimeline_c.add( new TweenLite.from('#lockup_ED_c', 0.25, {opacity:0, y:-20, ease: Strong.easeOut}));
  theTimeline_c.add( new TweenLite.from('#DDhand_c', 0.2, {opacity:0}));
  theTimeline_c.add( new TweenLite.from('#DDhand_c', 0.5, { y:-50, x:20, ease: Sine.easeOut}));
  theTimeline_c.add( new TweenLite.to('#DDhand_c', 0.25, { y:-20, x:8, ease: Sine.easeInOut}));
  theTimeline_c.add( new TweenLite.to('#DDhand_c', 0.75, { y:0, x:0, ease: Sine.easeInOut}));
}

function animateExpanded(){
  //vars
  var loopCount = 0;

  theTimeline.add( new TweenLite.from('#copy_holder', 0.75, {y:-250, delay:0.25, ease: Back.easeInOut}));
  theTimeline.add( new TweenLite.to('#copy2a', 0.2, {y:10, delay:0.35, ease: Sine.easeOut}));
  theTimeline.add( new TweenLite.to('#copy2a', 0.2, {y:0, ease: Sine.easeIn}));
  theTimeline.add( new TweenLite.to('#copy2b', 0.2, {y:10, ease: Sine.easeOut}));
  theTimeline.add( new TweenLite.to('#copy2b', 0.2, {y:0, ease: Sine.easeIn}));

  theTimeline.add( new TweenLite.from('#dd_riding_hand', 1, {y:400, ease: Back.easeInOut}));
  //theTimeline.add( new TweenLite.from('#butcher_holder', 1, {y:400, ease: Back.easeInOut, delay:-1}));
  theTimeline.add(buckingTimeline);
  theTimeline.add(buckingTimeline2);
  theTimeline.add(buckingTimeline3);

  buckingTimeline.add( new TweenMax.to('#dd_riding_hand', 0.5, {rotation:-15, ease: Sine.easeOut}));
  buckingTimeline.add( new TweenMax.to('#dd_riding_hand', 1, {rotation:15, ease: Sine.easeInOut, repeat:-1, yoyo:true}));

  buckingTimeline2.add( new TweenMax.to('#butcher_holder', 0.6, {rotation:12, ease: Sine.easeOut}));  
  buckingTimeline2.add( new TweenMax.to('#butcher_holder', 0.9, {rotation:-24, ease: Sine.easeInOut, repeat:-1, yoyo:true})); 

  buckingTimeline3.add( new TweenMax.to('#flag_holder', 0.6, {rotation:50, ease: Sine.easeOut}));  
  buckingTimeline3.add( new TweenMax.to('#flag_holder', 0.9, {rotation:26, ease: Sine.easeInOut, repeat:-1, yoyo:true}));


  var flag = document.getElementById('flag_AUS');
  drawAusFlag( flag, 200, 0, 15 );
  flag.style.marginLeft = -(flag.width/2)+'px';
  flag.style.marginTop  = -(flag.height/2)+'px';
  //var timer = waveFlag( flag, 20, 10, 150, 200, -0.1 );
  var timer = waveFlag( flag, 15, 5, 75, 100, -0.1 );


  function drawAusFlag( canvas, width, padX, padY ){
    if (!padX) padX = 0;
    if (!padY) padY = 0;

    var a = width / 2; //1.9
    var b = width;
    var c = 7*a/13;
    var d = 0.76*a;
    var e = 0.054*a;
    var g = 0.063*a;
    var k = 0.0616*a;
    var l = a / 13;
    canvas.width  = b+2*padX;
    canvas.height = a+2*padY;
    var ctx = canvas.getContext('2d');

    // Australian Flag
    ctx.fillStyle = '#00006B'; //00008B
    ctx.fillRect(padX,padY,b,a);

    //all coordinates are based on 200x100 flag.

    //St Andrew, St George BG
    ctx.fillStyle = '#FFF';
    ctx.fillRect(0,32, b/2,17);
    ctx.fillRect(42,padY, 16,50);

    ctx.fillStyle = '#FFF';
    ctx.beginPath();
    ctx.moveTo(0,15);
    ctx.lineTo(12,15);
    ctx.lineTo(100,60);
    ctx.lineTo(100,65);
    ctx.lineTo(88,65);
    ctx.lineTo(0,20);
    ctx.lineTo(0,15);

    ctx.moveTo(0,65);
    ctx.lineTo(0,60);
    ctx.lineTo(88,15);
    ctx.lineTo(100,15);
    ctx.lineTo(100,20);
    ctx.lineTo(12,65);
    ctx.lineTo(0,65);
    ctx.fill();

    //St George
    ctx.fillStyle = '#EE0000';
    ctx.fillRect(45,15, 10,50);
    ctx.fillRect(0,35, 100,10);
    
    //St Patrick
    ctx.fillStyle = '#EE0000';
    ctx.beginPath();
    ctx.moveTo(0,15);
    ctx.lineTo(32,32);
    ctx.lineTo(26,32);
    ctx.lineTo(0,18);
    ctx.lineTo(0,15);
    ctx.moveTo(0,65);
    ctx.lineTo(33,49);
    ctx.lineTo(40,49);
    ctx.lineTo(7,65);
    ctx.lineTo(0,65);
    ctx.moveTo(67,49);
    ctx.lineTo(74,49);
    ctx.lineTo(100,61);
    ctx.lineTo(100,66);
    ctx.lineTo(67,49);
    ctx.moveTo(61,32);
    ctx.lineTo(93,15);
    ctx.lineTo(100,15);
    ctx.lineTo(67,32);
    ctx.lineTo(61,32);
    ctx.fill();

    //Federation Star
    ctx.fillStyle = '#FFF';
    ctx.beginPath();
    ctx.moveTo(50,75);
    ctx.lineTo(53,83);
    ctx.lineTo(62,81);
    ctx.lineTo(57,88);
    ctx.lineTo(65,93);
    ctx.lineTo(55,94);
    ctx.lineTo(57,103);
    ctx.lineTo(50,97);
    ctx.lineTo(44,103);
    ctx.lineTo(45,94);
    ctx.lineTo(36,93);
    ctx.lineTo(43,88);
    ctx.lineTo(38,80);
    ctx.lineTo(47,84);
    ctx.lineTo(50,75);
    
    //Alpha crucius
    ctx.moveTo(150,91);
    ctx.lineTo(151,95);
    ctx.lineTo(155,94);
    ctx.lineTo(153,98);
    ctx.lineTo(157,100);
    ctx.lineTo(153,100);
    ctx.lineTo(153,104);
    ctx.lineTo(150,102);
    ctx.lineTo(147,105);
    ctx.lineTo(148,100);
    ctx.lineTo(143,100);
    ctx.lineTo(147,98);
    ctx.lineTo(145,94);
    ctx.lineTo(149,95);
    ctx.lineTo(150,91);

    //Beta crucius
    ctx.moveTo(150,25);
    ctx.lineTo(152,29);
    ctx.lineTo(156,27);
    ctx.lineTo(153,31);
    ctx.lineTo(157,33);
    ctx.lineTo(153,34);
    ctx.lineTo(153,38);
    ctx.lineTo(150,35);
    ctx.lineTo(147,38);
    ctx.lineTo(148,34);
    ctx.lineTo(143,33);
    ctx.lineTo(147,31);
    ctx.lineTo(145,27);
    ctx.lineTo(149,29);
    ctx.lineTo(150,25);

    //Gamma crucius
    ctx.moveTo(125,52);
    ctx.lineTo(126,56);
    ctx.lineTo(131,54);
    ctx.lineTo(128,58);
    ctx.lineTo(132,60);
    ctx.lineTo(128,60);
    ctx.lineTo(128,65);
    ctx.lineTo(125,62);
    ctx.lineTo(122,65);
    ctx.lineTo(122,61);
    ctx.lineTo(118,60);
    ctx.lineTo(122,58);
    ctx.lineTo(119,55);
    ctx.lineTo(124,56);
    ctx.lineTo(125,52);

    //Delta crucius
    ctx.moveTo(172,45);
    ctx.lineTo(174,49);
    ctx.lineTo(178,48);
    ctx.lineTo(175,51);
    ctx.lineTo(179,54);
    ctx.lineTo(175,54);
    ctx.lineTo(175,58);
    ctx.lineTo(172,55);
    ctx.lineTo(169,58);
    ctx.lineTo(170,54);
    ctx.lineTo(165,54);
    ctx.lineTo(169,51);
    ctx.lineTo(167,48);
    ctx.lineTo(170,49);
    ctx.lineTo(172,45);

    //Epsilon crucius
    ctx.moveTo(160,65);
    ctx.lineTo(161,66);
    ctx.lineTo(164,68);
    ctx.lineTo(162,70);
    ctx.lineTo(162,73);
    ctx.lineTo(160,71);
    ctx.lineTo(158,73);
    ctx.lineTo(158,70);
    ctx.lineTo(156,68);
    ctx.lineTo(159,68);
    ctx.lineTo(160,65);

    ctx.fill();

  }

function waveFlag( canvas, wavelength, amplitude, period, shading, squeeze ){
  if (!squeeze)    squeeze    = 0;
  if (!shading)    shading    = 100;
  if (!period)     period     = 200;
  if (!amplitude)  amplitude  = 10;
  if (!wavelength) wavelength = canvas.width/10;

  var fps = 30;
  var ctx = canvas.getContext('2d');
  var   w = canvas.width, h = canvas.height;
  var  od = ctx.getImageData(0,0,w,h).data;
  // var ct = 0, st=new Date;
  return setInterval(function(){
    var id = ctx.getImageData(0,0,w,h);
    var  d = id.data;
    var now = (new Date)/period;
    for (var y=0;y<h;++y){
      var lastO=0,shade=0;
      var sq = (y-h/2)*squeeze;
      for (var x=0;x<w;++x){
        var px  = (y*w + x)*4;
        var pct = x/w;
        var o   = Math.sin(x/wavelength-now)*amplitude*pct;
        var y2  = y + (o+sq*pct)<<0;
        var opx = (y2*w + x)*4;
        shade = (o-lastO)*shading;
        d[px  ] = od[opx  ]+shade;
        d[px+1] = od[opx+1]+shade;
        d[px+2] = od[opx+2]+shade;
        d[px+3] = od[opx+3];
        lastO = o;
      }
    }
    ctx.putImageData(id,0,0);   
    // if ((++ct)%100 == 0) console.log( 1000 * ct / (new Date - st));
  },1000/fps);
}


}


/**
 *  Main onload handler
 */
window.addEventListener('load', preInit);