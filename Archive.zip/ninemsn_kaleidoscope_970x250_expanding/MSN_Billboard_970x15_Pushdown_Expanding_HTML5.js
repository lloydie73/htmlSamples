// JavaScript Document
//HTML5 Ad Template JS from DoubleClick by Google

var collapsedPanel;
var expandedPanel;
var expandBtn;
var exitBtn;
var closeBtn;

// =============================================================================================
dcrmInit = function(){
	Enabler.setExpandingPixelOffsets(
  	0, // left offset of expanded ad
  	0, // top offset of expanded ad
 	970, // expanded width of ad
  	500); // expanded height of ad


	// Set Expansion to Auto-Expand
	//Enabler.setStartExpanded(true);
	slimbarPanel 		= document.getElementById('slimbarContent')
	slimbar_expandBtn 	= document.getElementById('expand_btn');

	collapsedPanel 		= document.getElementById('collapsed');
	expandBtn 			= document.getElementById('expand_btn2');
	//closeBtnCollapse 	= document.getElementById('close_btn_collapse');

	expandedPanel 		= document.getElementById('expanded');
	exit_btn 			= document.getElementById('exit_btn');
	
	closeBtnExpand 		= document.getElementById('close_btn_expand');
	
	// Added Listeners
	addListeners();
	setupExternalScript();

}


addListeners = function (){
	slimbar_expandBtn.addEventListener('click', onExpandHandlerSlimbar, false);

	expandBtn.addEventListener('click', onExpandHandler, false);
	//closeBtnCollapse.addEventListener('click', onCloseHandler_Col, false);

	exit_btn.addEventListener('click', onExitHandler, false);
	closeBtnExpand.addEventListener('click', onCloseHandler_Exp, false);



	// Expand Event Listeners
  	Enabler.addEventListener(studio.events.StudioEvent.EXPAND_START,
    function() {
    	
    	Enabler.startTimer('expanded_panel');
		slimbarPanel.style.display = "none";
		collapsedPanel.style.display = "none";
		expandedPanel.style.display = "block";
		resizeCreative(0, 970, 500, 0, false);
		setTimeout(function(){Enabler.finishExpand()}, 1000);
	});


  	// Collapse Event Listeners
  	Enabler.addEventListener(studio.events.StudioEvent.COLLAPSE_START,
    function() {
    	
		Enabler.stopTimer('expanded_panel');

    	setTimeout(function(){
    	Enabler.finishCollapse();
		},1000);

		});

  	// Collapse Finished
	Enabler.addEventListener(studio.events.StudioEvent.COLLAPSE_FINISH,
	function(){
		slimbarPanel.style.display = "none";
		expandedPanel.style.display = "none";
		collapsedPanel.style.display = "block";
	});

}

onExpandHandlerSlimbar = function(e){
	slimbarPanel.style.display = "none";
	collapsedPanel.style.display = "block";
	resizeCreative(0, 970, 250, 0, true);
}

onExpandHandler = function(e){
	Enabler.requestExpand();
	playExpandedTimeLine();
	
}

onExitHandler = function(e){
	//Enabler.exit('HTML5_Background_Clickthrough');
	//closeAd();
}

onCloseHandler_Col = function(e){
	
	/*
	Enabler.counter('Manual_Close');
	Enabler.reportManualClose();
	slimbarPanel.style.display = "block";
	collapsedPanel.style.display = "none";
	resizeCreative(0, 970, 31, 0, true);
	*/
}

onCloseHandler_Exp = function(e){
	Enabler.counter('Manual_Close');
	Enabler.reportManualClose();
	closeAd();
}

closeAd = function(){
	Enabler.requestCollapse();
}


window.onload = function() {
  /* Initialize Enabler */
  if (Enabler.isInitialized()) {
    dcrmInit();
  } else {
    Enabler.addEventListener(studio.events.StudioEvent.INIT, dcrmInit);
  }
}

/**
 * External JS calls.
 */

setupExternalScript = function() {
  var rand = "?" + Math.floor(Math.random()*1000000);
  var externalScript = '(function(){' +
      '  var extScript = document.createElement("script"); ' +
      //'  extScript.src = "' + Enabler.getUrl('dc_g5mh.js') + rand + '"; ' +
      '  extScript.src = "http://motifcdn2.doubleclick.net/EMEA/dc_templates/live/preview/2015/publisher/msn/pushdown/MSN_Billboard_Templates/resizeCreative.js' + rand + '"; ' +
      '  document.head.appendChild(extScript); ' +
      '})();';
  Enabler.invokeExternalJsFunction(externalScript);
};

resizeCreative = function(tl, tr, br, bl, updateDimension) {
   var externalScript =
      '(function(){' +
      '  studioV2.myAsset.setClip(' + tl + ',' + tr + ',' + br + ',' + bl + ');';
  if (updateDimension) {
      externalScript += '  studioV2.myAsset.setDimension(' + tr + ',' + br + ');';
  }
  externalScript += '  studioV2.myAsset.getContainerElement().firstChild.style.height = "' +
          br + 'px"; })();';
  Enabler.invokeExternalJsFunction(externalScript);
};  

var t1 = new TimelineLite();


t1.set('#termsContent',{y: -200, alpha: 1})

.to('#kaleidoscope', 5.0, {scale: 1})
.to('#kaleidoscope', .5, {alpha: 0})
.from('#logoMC', .4, {alpha: 0},'-=0.5')


.from('#quotes', 1, {alpha: 0,y: '+=30'})



.from('#txtRenaultClio', .4, {y: '-=100'},'-=0.5')

.from('#txtSays', .4, {x: '-=350'})
.from('#txtYou', .4, {x: '-=350'})



.from('#cta_Bar', 0.5, {alpha: 0},'-=0.5')
.from('#cta_Arrow', 0.5, {alpha: 0},'-=0.5')
.from('#cta_Bar', 0.5, {scaleX: 0.1})
.from('#cta_Arrow', 0.5, {x: '-=180'},'-=0.5')
.from('#cta_Text', 0.5, {alpha: 0},'-=0.2')


.from('#ctaDiscoverNow_Bar', 0.5, {alpha: 0},'-=0.5')
.from('#ctaDiscoverNow_Arrow', 0.5, {alpha: 0},'-=0.5')
.from('#ctaDiscoverNow_Bar', 0.5, {scaleX: 0.1})
.from('#ctaDiscoverNow_Arrow', 0.5, {x: '-=180'},'-=0.5')
.from('#ctaDiscoverNow_Text', 0.5, {alpha: 0},'-=0.2')



.to('#txtYou', .4, {alpha: '0'},'+=1')
.from('#txtColour', .4, {x: '-=400'})
.from('#carMainGrey', 0.5, {alpha: 0},'-=0.4')
.to('#logoMC', 2, {scale: 1})
.to('#txtRenaultClio', .4, {alpha: 0})

.to('#txtSays', .4, {alpha: 0},'-=0.4')
.to('#txtColour', .4, {alpha: 0},'-=0.4')
.from('#txtExpression', .4, {y: '-=100'})
.from('#Zero_x5F_Percent_x5F_Clio', .4, {x: '-=300'})
.from('#carMainRed', 0.4, {alpha: 0},'-=0.4')

.from('#bttnExpand', .4, {alpha: 0},'-=0.4')

.from('#termsBtn', 1, {alpha: 0},'-=1')

.to('#logoMC', 2, {scale: 1});






function termsContentOn() {
	TweenLite.to('#termsContent',0.5,{y: 0});
}

function termsContentOff() {
	TweenLite.to('#termsContent',0.5,{y: -200});
}


function oncta_BarOver(e) {
   	//TweenLite.set('#cta_Bar', {stroke: "#000000"});
   	TweenLite.set('#cta_Bar', {fill: "#333333"});
   	TweenLite.set('#cta_Text_On', {alpha: 0});
   	TweenLite.set('#cta_Text_Over', {alpha: 1});
   	TweenLite.set('#cta_Arrow_On', {alpha: 0});
   	TweenLite.set('#cta_Arrow_Over', {alpha: 1});
}   


function oncta_BarOut(e) {
   	//TweenLite.set('#cta_Bar', {stroke: "#FFCD34"});
   	TweenLite.set('#cta_Bar', {fill: "#FFCD34"});
   	TweenLite.set('#cta_Text_On', {alpha: 1});
   	TweenLite.set('#cta_Text_Over', {alpha: 0});
   	TweenLite.set('#cta_Arrow_On', {alpha: 1});
   	TweenLite.set('#cta_Arrow_Over', {alpha: 0});
  
} 

function onctaDiscoverNow_BarOver(e) {
  	
   	TweenLite.set('#ctaDiscoverNow_Bar', {fill: "#333333"});
   	TweenLite.set('#ctaDiscoverNow_Text_On', {alpha: 0});
   	TweenLite.set('#ctaDiscoverNow_Text_Over', {alpha: 1});
   	TweenLite.set('#ctaDiscoverNow_Arrow_On', {alpha: 0});
   	TweenLite.set('#ctaDiscoverNow_Arrow_Over', {alpha: 1});
   	
}   


function onctaDiscoverNow_BarOut(e) {
   
   	TweenLite.set('#ctaDiscoverNow_Bar', {fill: "#FFCD34"});
   	TweenLite.set('#ctaDiscoverNow_Text_On', {alpha: 1});
   	TweenLite.set('#ctaDiscoverNow_Text_Over', {alpha: 0});
   	TweenLite.set('#ctaDiscoverNow_Arrow_On', {alpha: 1});
   	TweenLite.set('#ctaDiscoverNow_Arrow_Over', {alpha: 0});
  
}



function ctaExit_Collapsed(e) {
    Enabler.exit('RenExit_Collapsed');
    //alert('Exit Click');
} 

function ctaExit_Expanded(e) {
    Enabler.exit('RenExit_Expanded');
    //alert('Exit Click');
} 
function ctaBrochureExit_Collapsed(e) {
    Enabler.exit('RenExitBrochure_Collapsed');
    //alert('Exit Click');
} 

function ctaBrochureExit_Expanded(e) {
    Enabler.exit('RenExitBrochure_Expanded');
    //alert('Exit Click');
} 

 



document.getElementById('cta').addEventListener('click', ctaBrochureExit_Collapsed, false);
document.getElementById('ctaDiscoverNow').addEventListener('click', ctaExit_Expanded, false);

document.getElementById('cta').addEventListener('mouseover', oncta_BarOver, false);
document.getElementById('ctaDiscoverNow').addEventListener('mouseover', onctaDiscoverNow_BarOver, false);

document.getElementById('cta').addEventListener('mouseout', oncta_BarOut, false);
document.getElementById('ctaDiscoverNow').addEventListener('mouseout', onctaDiscoverNow_BarOut, false);

function ctaDiscoverMouseOver(e){
	TweenLite.set('#ctaDiscoverOver', {alpha: 1});
}
function ctaDiscoverMouseOut(e){
	TweenLite.set('#ctaDiscoverOver', {alpha: 0});
}
function ctaDiscoverMouseClick(e){
	alert('cta discover click');
}

function ctaBrochureMouseOver(e){
	TweenLite.set('#ctaBrochureOver', {alpha: 1});
}
function ctaBrochureMouseOut(e){
	TweenLite.set('#ctaBrochureOver', {alpha: 0});
}
function ctaBrochureMouseClick(e){
	alert('cta brochure click');
}









document.getElementById('ctaDiscoverOver').addEventListener('mouseover', ctaDiscoverMouseOver, false);
document.getElementById('ctaDiscoverOver').addEventListener('mouseout', ctaDiscoverMouseOut, false);
document.getElementById('ctaDiscoverOver').addEventListener('click', ctaExit_Expanded, false);

document.getElementById('ctaBrochureOver').addEventListener('mouseover', ctaBrochureMouseOver, false);
document.getElementById('ctaBrochureOver').addEventListener('mouseout', ctaBrochureMouseOut, false);
document.getElementById('ctaBrochureOver').addEventListener('click', ctaBrochureExit_Expanded, false);
document.getElementById('bgBttn').addEventListener('click', ctaExit_Expanded, false);

document.getElementById('expandedBGBtn').addEventListener('click', ctaExit_Expanded, false);









